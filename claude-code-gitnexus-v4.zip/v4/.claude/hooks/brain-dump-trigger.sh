#!/usr/bin/env bash
# PostToolUse hook — triggers BRAIN_DUMP.md regeneration every 10 commits.
#
# After every successful `git commit`, this hook counts total commits on the
# current branch. When the count is a multiple of 10, it signals Claude to
# invoke the @context-synthesizer agent to regenerate BRAIN_DUMP.md.
#
# Why BRAIN_DUMP.md?
#   Opus reads every .md file at session start. A 500-token BRAIN_DUMP beats
#   re-reading 10 handoff docs, 20 ADRs, and 50 commit messages. Agents read
#   BRAIN_DUMP.md first — it is the single fastest way to orient a new session.
#
# Fails open on any error — never blocks the commit.

set -uo pipefail

if ! command -v jq >/dev/null 2>&1; then
  exit 0
fi

INPUT=$(cat)
TOOL_NAME=$(echo "$INPUT" | jq -r '.tool_name // ""')
[[ "$TOOL_NAME" != "Bash" ]] && exit 0

COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // ""')
# Only fire after git commit (not merge, rebase, etc. — those are handled by gitnexus-hook)
if ! echo "$COMMAND" | grep -qE '^git commit|git commit '; then
  exit 0
fi

# Only if the commit succeeded
EXIT_CODE=$(echo "$INPUT" | jq -r '.tool_response.exit_code // 0')
[[ "$EXIT_CODE" != "0" ]] && exit 0

PROJECT_ROOT="${CLAUDE_PROJECT_DIR:-$(pwd)}"

# Count commits on current branch
COMMIT_COUNT=$(git -C "$PROJECT_ROOT" rev-list --count HEAD 2>/dev/null || echo "0")

# Trigger on every 10th commit
if (( COMMIT_COUNT % 10 != 0 )); then
  exit 0
fi

# Signal to Claude to regenerate BRAIN_DUMP
cat << EOF
{
  "hookSpecificOutput": {
    "hookEventName": "PostToolUse",
    "additionalContext": "🧠 Brain dump trigger: $COMMIT_COUNT commits reached. Invoke @context-synthesizer now to regenerate BRAIN_DUMP.md. This compresses project context so future sessions read one file instead of the full history. Run: invoke context-synthesizer with task 'regenerate BRAIN_DUMP.md'"
  }
}
EOF
