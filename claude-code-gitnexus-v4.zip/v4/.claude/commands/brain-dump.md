---
description: Manually trigger a BRAIN_DUMP.md regeneration — compresses full project history into a single 400-600 token file that orients any new session instantly. Runs automatically every 10 commits; use this to force an early update. Usage: /brain-dump
---

Invoke @context-synthesizer with the following instruction:

"Regenerate BRAIN_DUMP.md now. This is a manual trigger — the user wants
an up-to-date context compression before starting new work or handing off
to another session. Follow your full standard protocol."

After the synthesizer completes, report:
- Path: `BRAIN_DUMP.md`
- Word count
- What changed since the last synthesis (if a previous version existed)
- When the next automatic trigger will fire (next multiple of 10 commits)
