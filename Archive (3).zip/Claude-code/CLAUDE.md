# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Repository Is

This is the **orchestrated-project-template** — a GitHub template repository that bootstraps new software projects with a full multi-agent Claude Code setup. It is not itself an application; it is the scaffold that other projects are built from.

Running `/start` inside a new repo created from this template triggers the onboarding protocol in `START_HERE.md`, which gathers project details from the user and fills every placeholder across all documentation files.

---

## Repository Structure

```
CLAUDE.md                     # Master Claude instructions (this file)
PRD.md                        # Product Requirements Document template (read-only for agents)
TODO.md                       # Living backlog (placeholder until /start fills it)
START_HERE.md                 # Onboarding protocol — deleted after /start completes
SOUL.md                       # Design philosophy behind the template (human reference)
.mcp.json                     # MCP server config: sequential-thinking + context7
.claude/
  settings.json               # Hook wiring (PreToolUse, PostToolUse, Stop, SubagentStart)
  agents/                     # 12 specialist sub-agent definitions
  commands/                   # Slash command implementations (orchestrate, review, release, checkpoint, status, start, sync-template)
  hooks/                      # Lifecycle hook shell scripts (chmod +x required)
  rules/                      # File-scoped rule injection (typescript.md, migrations.md, tests.md)
  templates/                  # Blank doc templates copied into place by /start
.tasks/                       # Task files (one per TODO item); TASK_TEMPLATE.md is the canonical form
.github/
  PULL_REQUEST_TEMPLATE.md    # PR description template
docs/                         # Created from .claude/templates/ during /start onboarding
```

---

## Agents

12 specialist agents live in `.claude/agents/`. Each has a defined domain, a document it owns, and scoped MCP access. The orchestrator (main Claude instance) routes tasks; specialists implement.

| Agent | Model | Owns |
|-------|-------|------|
| `project-manager` | Sonnet | `TODO.md` |
| `systems-architect` | Opus | `ARCHITECTURE.md`, `DECISIONS.md` |
| `frontend-developer` | Sonnet | Frontend section of `ARCHITECTURE.md` |
| `react-native-developer` | Sonnet | Mobile section of `ARCHITECTURE.md` |
| `backend-developer` | Sonnet | `API.md` |
| `ui-ux-designer` | Sonnet | `docs/technical/DESIGN_SYSTEM.md` |
| `database-expert` | Sonnet | `DATABASE.md` |
| `qa-engineer` | Sonnet | `tests/e2e/` |
| `documentation-writer` | Haiku | `USER_GUIDE.md` |
| `cicd-engineer` | Sonnet | `.github/workflows/` |
| `docker-expert` | Sonnet | `Dockerfile*`, `docker-compose*.yml` |
| `copywriter-seo` | Sonnet | `docs/content/CONTENT_STRATEGY.md` |

**Delegation is mandatory.** Tasks within a specialist's domain must be routed to that agent — do not implement directly.

---

## Lifecycle Hooks

All four hooks are wired in `.claude/settings.json` and fire automatically:

| Hook | Trigger | Effect |
|------|---------|--------|
| `guard-destructive.sh` | `PreToolUse: Bash` | Blocks `rm -rf`, `git push --force`, `DROP TABLE`, `npm publish`, direct pushes to `main` |
| `format-on-write.sh` | `PostToolUse: Write\|Edit` | Runs prettier/eslint (JS/TS), ruff/black (Python), gofmt (Go), rustfmt — no-ops if tooling absent |
| `validate-completion.sh` | `Stop` | Warns if implementation files changed but `docs/` or `TODO.md` were not updated |
| `log-agent.sh` | `SubagentStart` | Appends timestamped line to `.claude/agent-log.txt` |

Hooks must remain `chmod +x`. Test them by running the scripts directly with a `CLAUDE_PROJECT_DIR` env var set.

---

## Slash Commands

| Command | File | Purpose |
|---------|------|---------|
| `/start` | `.claude/commands/start.md` | Full onboarding from `START_HERE.md` — run once per new project |
| `/orchestrate <task>` | `.claude/commands/orchestrate.md` | Multi-agent wave execution with approval gate |
| `/review [scope]` | `.claude/commands/review.md` | Architect + QA + implementation review on branch diff |
| `/release [version]` | `.claude/commands/release.md` | Pre-release QA, docs, and CI/CD checklist |
| `/checkpoint [desc]` | `.claude/commands/checkpoint.md` | Lint/test, update docs, commit WIP |
| `/status` | `.claude/commands/status.md` | Live project health card |
| `/sync-template` | `.claude/commands/sync-template.md` | Pull latest `.claude/` from upstream template |

---

## Critical Rules

1. **`PRD.md` requires explicit human approval to modify.** Read it; never edit without a direct instruction in the current conversation.
2. **`TODO.md` is the living backlog.** Agents may add items and mark items complete. Never reorder items within a section unless explicitly asked.
3. **All commits use Conventional Commits format**: `<type>(<scope>): <short description>`
4. **Update the relevant `docs/` file** after every significant change before marking a task complete.
5. **Run tests before marking any implementation task complete.**
6. **Consult `docs/technical/DECISIONS.md`** before proposing changes that conflict with prior ADRs.
7. **Commit locally; never push.** The orchestrator pushes branches and opens PRs.

---

## Working on the Template Itself

When modifying the template (not a project built from it):

- **Agent definitions** (`.claude/agents/*.md`) — edit the markdown directly; changes take effect in the next sub-agent invocation.
- **Hook scripts** (`.claude/hooks/*.sh`) — keep them POSIX-compatible and exit-code–correct: exit `2` to block, exit `0` to pass, write to stderr for user-visible messages.
- **Slash commands** (`.claude/commands/*.md`) — these are prompt templates; prose changes are sufficient.
- **Doc templates** (`.claude/templates/`) — these are the upstream originals copied by `/start`; do not edit them as part of an active project's workflow.
- **`START_HERE.md`** — deleted at the end of onboarding; edit it to change the onboarding sequence.

---

## Git Conventions

```
feat(agents): add react-native-developer specialist
fix(hooks): guard-destructive blocks npm publish
docs(readme): clarify /sync-template usage
chore(templates): update TASK_TEMPLATE frontmatter fields
```

Branch naming: `feature/<ticket-id>-short-description` · `fix/<ticket-id>-short-description` · `docs/<description>`

---

## MCP Servers

Declared in `.mcp.json` (committed, shared with the team). Both are unauthenticated.

- `sequential-thinking` — structured multi-step reasoning for `systems-architect` and `project-manager`
- `context7` — live library documentation for `frontend-developer`, `react-native-developer`, `backend-developer`, `database-expert`, `docker-expert`
